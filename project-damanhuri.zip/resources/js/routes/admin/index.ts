import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import analytics from './analytics'
import labs7ab630 from './labs'
/**
* @see \App\Http\Controllers\AnalyticsController::dashboard
 * @see app/Http/Controllers/AnalyticsController.php:14
 * @route '/admin'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/admin',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AnalyticsController::dashboard
 * @see app/Http/Controllers/AnalyticsController.php:14
 * @route '/admin'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AnalyticsController::dashboard
 * @see app/Http/Controllers/AnalyticsController.php:14
 * @route '/admin'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AnalyticsController::dashboard
 * @see app/Http/Controllers/AnalyticsController.php:14
 * @route '/admin'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AnalyticsController::dashboard
 * @see app/Http/Controllers/AnalyticsController.php:14
 * @route '/admin'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AnalyticsController::dashboard
 * @see app/Http/Controllers/AnalyticsController.php:14
 * @route '/admin'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AnalyticsController::dashboard
 * @see app/Http/Controllers/AnalyticsController.php:14
 * @route '/admin'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm
/**
* @see \App\Http\Controllers\LabsController::labs
 * @see app/Http/Controllers/LabsController.php:23
 * @route '/admin/labs'
 */
export const labs = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: labs.url(options),
    method: 'get',
})

labs.definition = {
    methods: ["get","head"],
    url: '/admin/labs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LabsController::labs
 * @see app/Http/Controllers/LabsController.php:23
 * @route '/admin/labs'
 */
labs.url = (options?: RouteQueryOptions) => {
    return labs.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LabsController::labs
 * @see app/Http/Controllers/LabsController.php:23
 * @route '/admin/labs'
 */
labs.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: labs.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LabsController::labs
 * @see app/Http/Controllers/LabsController.php:23
 * @route '/admin/labs'
 */
labs.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: labs.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\LabsController::labs
 * @see app/Http/Controllers/LabsController.php:23
 * @route '/admin/labs'
 */
    const labsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: labs.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\LabsController::labs
 * @see app/Http/Controllers/LabsController.php:23
 * @route '/admin/labs'
 */
        labsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: labs.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\LabsController::labs
 * @see app/Http/Controllers/LabsController.php:23
 * @route '/admin/labs'
 */
        labsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: labs.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    labs.form = labsForm
const admin = {
    dashboard: Object.assign(dashboard, dashboard),
analytics: Object.assign(analytics, analytics),
labs: Object.assign(labs, labs7ab630),
}

export default admin