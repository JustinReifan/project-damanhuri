import { Heart, MessageCircle, Target } from 'lucide-react';

export default function Instructor() {
    return (
        <section id="pengajar" className="bg-white py-16 sm:py-24">
            <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
                <div className="grid items-center gap-10 lg:grid-cols-5 lg:gap-16">
                    {/* Left: Avatar placeholder image */}
                    <div className="flex justify-center lg:col-span-2">
                        <div className="relative">
                            <div className="h-56 w-56 overflow-hidden rounded-2xl bg-gradient-to-br from-lp-blue-100 to-lp-blue-200 shadow-lg sm:h-64 sm:w-64">
                                {/* Placeholder portrait silhouette */}
                                <div className="flex h-full w-full flex-col items-center justify-center">
                                    <svg
                                        className="h-28 w-28 text-lp-blue-300 sm:h-32 sm:w-32"
                                        fill="currentColor"
                                        viewBox="0 0 24 24"
                                    >
                                        <path d="M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v1.2c0 .7.5 1.2 1.2 1.2h16.8c.7 0 1.2-.5 1.2-1.2v-1.2c0-3.2-6.4-4.8-9.6-4.8z" />
                                    </svg>
                                    <p className="mt-1 text-sm font-semibold text-lp-blue-500">
                                        Rashid Damanhuri
                                    </p>
                                </div>
                            </div>
                            {/* Accent decoration */}
                            <div className="absolute -right-3 -bottom-3 h-full w-full rounded-2xl border-2 border-lp-blue-200" />
                        </div>
                    </div>

                    {/* Right: Bio */}
                    <div className="lg:col-span-3">
                        <span className="mb-3 inline-block text-sm font-medium text-lp-blue-600">
                            Tentang Pengajar
                        </span>
                        <h2 className="text-2xl font-semibold text-lp-slate-900 sm:text-3xl">
                            Mohammad Rashid Damanhuri, S.I.Kom., M.M.
                        </h2>
                        <p className="mt-4 text-base leading-relaxed text-lp-slate-600">
                            Saya percaya bahwa belajar bisnis itu tidak harus
                            rumit. Justru yang paling penting adalah memulai
                            dengan langkah yang benar — dan itulah yang saya
                            bantu lewat panduan ini.
                        </p>
                        <p className="mt-3 text-base leading-relaxed text-lp-slate-600">
                            Panduan ini saya buat berdasarkan pengalaman 12
                            tahun bisnis dan kuliah S2 sebagai dasar teori.
                            Semuanya saya jelaskan pakai bahasa sederhana yang
                            bisa dipahami siapa saja — termasuk kamu yang baru
                            pertama kali mau bisnis.
                        </p>

                        <div className="mt-8 grid gap-4 sm:grid-cols-3">
                            <div className="flex items-start gap-3">
                                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-lp-blue-50">
                                    <Heart className="h-6 w-6 text-lp-blue-600" />
                                </div>
                                <div>
                                    <p className="text-sm font-semibold text-lp-slate-700">
                                        Praktis
                                    </p>
                                    <p className="text-xs text-lp-slate-400">
                                        Bukan sekadar teori
                                    </p>
                                </div>
                            </div>
                            <div className="flex items-start gap-3">
                                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-lp-blue-50">
                                    <MessageCircle className="h-6 w-6 text-lp-blue-600" />
                                </div>
                                <div>
                                    <p className="text-sm font-semibold text-lp-slate-700">
                                        Sederhana
                                    </p>
                                    <p className="text-xs text-lp-slate-400">
                                        Bahasa sehari-hari
                                    </p>
                                </div>
                            </div>
                            <div className="flex items-start gap-3">
                                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-lp-blue-50">
                                    <Target className="h-6 w-6 text-lp-blue-600" />
                                </div>
                                <div>
                                    <p className="text-sm font-semibold text-lp-slate-700">
                                        Terarah
                                    </p>
                                    <p className="text-xs text-lp-slate-400">
                                        Step-by-step jelas
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}
